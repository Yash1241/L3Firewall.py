# pox/forwarding/L3Firewall.py

from pox.core import core
import pox.openflow.libopenflow_01 as of
from pox.lib.revent import EventMixin
from pox.lib.util import dpidToStr
from pox.lib.addresses import EthAddr, IPAddr
import os
import csv
import argparse # >> CHANGE HERE: Keep argparse as it's used in your launch function.

from pox.lib.packet import ethernet, ETHER_BROADCAST
from pox.lib.packet import arp
from pox.lib.packet import ipv4
from pox.lib.packet import icmp # >> ADDITION HERE: Explicitly import icmp for protocol handling
from pox.lib.packet import tcp

log = core.getLogger()
priority = 50000

# >> REMOVAL HERE: mac_ip_map and blocked_macs were global, moved to instance variables in __init__.
# mac_ip_map = {} # Post Security data structure
# blocked_macs = set()

# >> REMOVAL HERE: Global l2config and l3config assignments removed, now handled by launch and __init__.
# l2config = "l2firewall.config"
# l3config = "l3firewall.config"

class Firewall(EventMixin):
    def __init__(self, l2config="l2firewall.config", l3config="l3firewall.config"):
        core.listenTo(core.openflow) # >> CHANGE HERE: Use core.openflow directly for listener registration
        core.openflow.addListenerByName("PacketIn", self._handle_PacketIn)
        core.openflow.addListenerByName("ConnectionUp", self._handle_ConnectionUp)

        # >> ADDITION HERE: Port Security data structures are now instance variables
        self.mac_ip_map = {} # Stores the first legitimate IP seen for a given MAC address. {EthAddr: IPAddr}
        self.blocked_macs = set() # Stores MAC addresses identified as spoofing. set of EthAddr.

        self.disbaled_MAC_pair = []
        self.fwconfig = [] # This seems unused in your code snippets.

        self.l2config_file = l2config # >> CHANGE HERE: Use l2config passed from launch function
        self.l3config_file = l3config # >> CHANGE HERE: Use l3config passed from launch function

        # Read the CSV file (L2 firewall config)
        # >> CHANGE HERE: Corrected logic for default config values and file open mode.
        if not self.l2config_file:
            self.l2config_file = "l2firewall.config"
        try:
            with open(self.l2config_file, 'r') as rules:
                csvreader = csv.DictReader(rules)
                for line in csvreader:
                    mac_0 = EthAddr(line['mac_0']) if line['mac_0'] != 'any' else None
                    mac_1 = EthAddr(line['mac_1']) if line['mac_1'] != 'any' else None
                    self.disbaled_MAC_pair.append((mac_0, mac_1))
            log.info(f"Loaded L2 firewall rules from {self.l2config_file}")
        except Exception as e:
            log.error(f"Error loading L2 firewall config {self.l2config_file}: {e}")
            self.disbaled_MAC_pair = [] # >> ADDITION HERE: Ensure empty list if loading fails

        # L3 firewall config loading
        self.rules = [] # >> ADDITION HERE: Initialize rules list for L3 firewall
        # >> CHANGE HERE: Corrected logic for default config values and file open mode.
        if not self.l3config_file:
            self.l3config_file = "l3firewall.config"
        try:
            with open(self.l3config_file, 'r') as csvfile:
                log.debug("Reading log file !")
                csvreader = csv.DictReader(csvfile)
                for row in csvreader:
                    log.debug("Saving individual rule parameters in rule dict !")
                    prio = int(row['priority']) # >> CHANGE HERE: Convert 'priority' to int
                    srcmac = EthAddr(row['src_mac']) if row['src_mac'] != 'any' else None # >> CHANGE HERE: Use EthAddr
                    dstmac = EthAddr(row['dst_mac']) if row['dst_mac'] != 'any' else None # >> CHANGE HERE: Use EthAddr
                    s_ip = IPAddr(row['src_ip']) if row['src_ip'] != 'any' else None # >> CHANGE HERE: Use IPAddr
                    d_ip = IPAddr(row['dst_ip']) if row['dst_ip'] != 'any' else None # >> CHANGE HERE: Use IPAddr
                    s_port = int(row['src_port']) if row['src_port'] != 'any' else None # >> CHANGE HERE: Convert to int
                    d_port = int(row['dst_port']) if row['dst_port'] != 'any' else None # >> CHANGE HERE: Convert to int
                    nw_proto_str = row['nw_proto']

                    nw_proto = 0 # Default if not recognized
                    if nw_proto_str.lower() == "tcp":
                        nw_proto = ipv4.TCP_PROTOCOL
                    elif nw_proto_str.lower() == "icmp":
                        nw_proto = ipv4.ICMP_PROTOCOL
                    elif nw_proto_str.lower() == "udp":
                        nw_proto = ipv4.UDP_PROTOCOL
                    else:
                        log.warning(f"Unknown network protocol '{nw_proto_str}' in {self.l3config_file}. Rule ignored.") # >> ADDITION HERE: Warning for unknown protocol
                        continue

                    self.rules.append({
                        'priority': prio,
                        'src_mac': srcmac, 'dst_mac': dstmac,
                        'src_ip': s_ip, 'dst_ip': d_ip,
                        'src_port': s_port, 'dst_port': d_port,
                        'nw_proto': nw_proto
                    })
            log.info(f"Loaded L3 firewall rules from {self.l3config_file}")
        except Exception as e:
            log.error(f"Error loading L3 firewall config {self.l3config_file}: {e}")
            self.rules = [] # >> ADDITION HERE: Ensure empty list if loading fails

        log.debug("Enabling Firewall Module")
        log.info("Firewall (with Port Security) module initialized.")
        log.debug(f"Initial mac_ip_map: {self.mac_ip_map}") # >> ADDITION HERE: Debugging current state of map

    def _handle_ConnectionUp(self, event):
        """
        Installs L2 firewall rules when a switch connects.
        """
        log.info(f"Switch {dpidToStr(event.dpid)} connected. Installing L2 firewall rules.")
        self.connection = event.connection
        for source, destination in self.disbaled_MAC_pair:
            print(source, destination)
            message = of.ofp_flow_mod()
            match = of.ofp_match()
            match.dl_src = source
            match.dl_dst = destination
            message.priority = 65535
            message.match = match
            event.connection.send(message)

        log.debug(f"Firewall rules: %s", dpidToStr(event.dpid))


    def _handle_PacketIn(self, event):
        """
        Handles PacketIn events from the switch. This is the main logic for
        port security and L3 firewalling.
        """
        packet = event.parsed
        if not packet.parsed:
            log.warning("Ignoring unparsed packet (no higher-layer protocol).") # >> ADDITION HERE: More specific warning
            return

        match = of.ofp_match.from_packet(packet)
        connection = event.connection
        dl_src = packet.src

        log.info(f"\nPacketIn: DPID={dpidToStr(event.dpid)}, Port={event.port}, Src MAC={dl_src}, Dst MAC={packet.dst}") # >> ADDITION HERE: More detailed logging

        # >> ADDITION HERE: --- PORT SECURITY LOGIC ---
        # 1. Check if source MAC is already in the blocked set (due to prior spoofing detection)
        if dl_src in self.blocked_macs: # >> CHANGE HERE: Use self.blocked_macs instance variable
            log.info(f"Drop packet from blocked Mac: {dl_src}")
            # Re-install a high-priority drop rule just in case it was removed or expired
            msg = of.ofp_flow_mod()
            msg.match.dl_src = dl_src
            msg.priority = 65535 # Max priority to guarantee block
            msg.hard_timeout = 0
            msg.idle_timeout = 0
            connection.send(msg)
            return # Block the packet and stop processing

        # 2. Handle ARP packets before IP packets
        if match.dl_type == packet.ARP_TYPE and match.nw_proto == arp.REQUEST:
            self.replyToARP(packet, match, event)
            return

        # 3. Apply port security (MAC-IP binding) for IPv4 packets
        if match.dl_type == packet.IP_TYPE:
            ip_packet = packet.find('ipv4') # >> CHANGE HERE: Correct way to get parsed IPv4 object
            if ip_packet:
                print(f"IP packet.protocol = {ip_packet.protocol}")
                if ip_packet.protocol == ipv4.TCP_PROTOCOL:
                    log.debug("TCP it is !")

                src_ip = ip_packet.srcip # >> CHANGE HERE: Get src_ip from the parsed ip_packet
                log.debug(f"nw_src = {src_ip}")

                if dl_src in self.mac_ip_map: # >> CHANGE HERE: Use self.mac_ip_map instance variable
                    if self.mac_ip_map[dl_src] != src_ip: # >> CHANGE HERE: Use self.mac_ip_map and src_ip
                        log.warning(f"spoof detected MAC {dl_src} (OG IP {self.mac_ip_map[dl_src]}) uses IP {src_ip}") # >> CHANGE HERE: Correct logging with instance var
                        self.blocked_macs.add(dl_src) # >> CHANGE HERE: Use self.blocked_macs instance variable
                        # Install drop rule with highest priority for spoofed MAC
                        msg = of.ofp_flow_mod()
                        msg.match.dl_src = dl_src
                        msg.priority = 65535 # Max priority to guarantee block
                        msg.hard_timeout = 0
                        msg.idle_timeout = 0
                        connection.send(msg)
                        return # Block the packet and stop processing
                else:
                    self.mac_ip_map[dl_src] = src_ip # >> CHANGE HERE: Use self.mac_ip_map instance variable
                    log.info(f"Port sec: legitimate mapping: MAC {dl_src} -> IP {src_ip}") # >> CHANGE HERE: Correct logging

            else:
                log.warning(f"  Ethernet type IP_TYPE, but no IPv4 packet parsed. Skipping Port Security check.") # >> ADDITION HERE: Warning for unparsed IP
        else:
            log.info(f"  Non-IP/ARP packet (type={packet.type}). Falling through to general firewall/forwarding.") # >> ADDITION HERE: Info for other types

        # >> CHANGE HERE: --- L3 FIREWALL RULES PROCESSING AND FORWARDING ---
        # >> Call replyToIP which applies L3 rules and then calls allowOther if no block.
        self.replyToIP(packet, match, event, self.rules) # >> CHANGE HERE: Pass self.rules (fwconfig param)


    def replyToARP(self, packet, match, event):
        """
        Handles ARP requests by crafting and sending an ARP reply.
        """
        r = arp.arp()
        r.opcode = arp.REPLY
        arp_pkt = packet.find('arp')
        if arp_pkt: # >> ADDITION HERE: Ensure arp_pkt is not None
            r.hwsrc = arp_pkt.protodst_hw # >> CHANGE HERE: Use protodst_hw from parsed ARP packet
            r.protodst = arp_pkt.protosrc
            r.protosrc = arp_pkt.protodst
            r.hwdst = arp_pkt.hwsrc

            e = ethernet(type=packet.ARP_TYPE, src=r.hwsrc, dst=r.hwdst)
            e.set_payload(r)

            msg = of.ofp_packet_out()
            msg.data = e.pack()
            msg.actions.append(of.ofp_action_output(port = of.OFPP_IN_PORT))
            msg.in_port = event.port
            event.connection.send(msg)
            log.debug(f"Replied to ARP for {r.protodst} with MAC {r.hwsrc}") # >> ADDITION HERE: More informative log
        else:
            log.warning("Could not parse ARP packet for reply.") # >> ADDITION HERE: Warning for failed ARP parse


    def allowOther(self, event):
        """
        A fallback to allow general forwarding if no specific firewall rule matches.
        This sends the packet to the OFPP_NORMAL port, which often means
        the switch's internal learning logic takes over.
        """
        msg = of.ofp_flow_mod()
        msg.match = of.ofp_match.from_packet(event.parsed, event.port)
        # >> CHANGE HERE: Set idle_timeout and hard_timeout for forwarding rules for better persistence
        msg.idle_timeout = 60
        msg.hard_timeout = 0
        msg.actions.append(of.ofp_action_output(port = of.OFPP_NORMAL))
        msg.data = event.ofp # >> ADDITION HERE: Include original packet data for immediate sending
        event.connection.send(msg)
        log.debug(f"Installed allowOther (OFPP_NORMAL) flow for {dpidToStr(event.dpid)}") # >> ADDITION HERE: More informative log


    def installFlow(self, event, priol, srcmac1, dstmac1, s_ip1, d_ip1, s_port1, d_port1, nw_proto1):
        """
        Installs a flow rule based on the provided parameters.
        As seen in your code, if no action is explicitly added, this function
        will result in packets matching these criteria being DROPPED.
        """
        msg = of.ofp_flow_mod()
        match = of.ofp_match()

        if srcmac1 is not None:
            match.dl_src = srcmac1
        if dstmac1 is not None:
            match.dl_dst = dstmac1

        # >> CHANGE HERE: Ensure dl_type is set for L3/L4 matching.
        is_ip_match = (s_ip1 is not None or d_ip1 is not None or
                       s_port1 is not None or d_port1 is not None or nw_proto1 is not None)
        if is_ip_match:
            match.dl_type = ethernet.IP_TYPE

        if s_ip1 is not None:
            match.nw_src = s_ip1
        if d_ip1 is not None:
            match.nw_dst = d_ip1

        if nw_proto1 is not None:
            match.nw_proto = nw_proto1

        # Transport layer port matching
        if s_port1 is not None:
            if nw_proto1 == ipv4.TCP_PROTOCOL:
                match.tp_src = s_port1
            # >> ADDITION HERE: Placeholder for UDP port matching if needed
            # elif nw_proto1 == ipv4.UDP_PROTOCOL:
            #     match.tp_src = s_port1
        if d_port1 is not None:
            if nw_proto1 == ipv4.TCP_PROTOCOL:
                match.tp_dst = d_port1
            # >> ADDITION HERE: Placeholder for UDP port matching if needed
            # elif nw_proto1 == ipv4.UDP_PROTOCOL:
            #     match.tp_dst = d_port1

        msg.match = match
        msg.hard_timeout = 0
        msg.idle_timeout = 200
        msg.priority = priol + priority

        # No actions explicitly added -> implies DROP for this flow rule.
        event.connection.send(msg)
        log.debug(f"Installed L3 flow rule (potentially drop): priority={msg.priority}, match={match}") # >> ADDITION HERE: More informative log


    def replyToIP(self, packet, match, event, fwconfig):
        """
        Processes IP packets against L3 firewall rules and forwards if allowed.
        """
        log.debug("You are in original code block ...")

        # >> NOTE: This following block from your original code is largely redundant
        # >> with the rule parsing done in __init__ and the loop that follows.
        # >> It's included here because you asked for the code from before its removal discussion.
        # >> For a cleaner, more efficient, and correct implementation, this block should ideally be removed
        # >> (as discussed in the prompt after the last "go back" request).

        # Attempt to get values directly from the match/packet,
        # but this doesn't use the pre-loaded self.rules directly.
        srcmac1 = EthAddr(match.dl_src) if match.dl_src != 'any' else None
        dstmac1 = EthAddr(match.dl_dst) if match.dl_dst != 'any' else None

        ip_packet = packet.find('ipv4') # Get the IP packet from the event
        s_ip1 = ip_packet.srcip if ip_packet else None
        d_ip1 = ip_packet.dstip if ip_packet else None

        tcp_packet = packet.find('tcp')
        # udp_packet = packet.find('udp') # If UDP parsing is added later

        s_port1 = tcp_packet.srcport if tcp_packet else None
        d_port1 = tcp_packet.dstport if tcp_packet else None

        nw_proto1 = 0
        if ip_packet:
            if ip_packet.protocol == ipv4.TCP_PROTOCOL:
                nw_proto1 = ipv4.TCP_PROTOCOL
            elif ip_packet.protocol == ipv4.ICMP_PROTOCOL:
                nw_proto1 = ipv4.ICMP_PROTOCOL
                s_port1 = None
                d_port1 = None
            elif ip_packet.protocol == ipv4.UDP_PROTOCOL:
                nw_proto1 = ipv4.UDP_PROTOCOL
                # If UDP parsing is fully integrated for ports:
                # udp_packet = packet.find('udp')
                # s_port1 = udp_packet.srcport if udp_packet else None
                # d_port1 = udp_packet.dstport if udp_packet else None
            else:
                log.debug("PROTOCOL field is mandatory, Choose between ICMP, TCP, UDP or check rule logic.")
        else:
            log.debug("Packet is not IPv4, cannot apply L3/L4 rules based on this original block.")

        print (f"{priority}, {s_ip1}, {d_ip1}, {s_port1}, {d_port1}, {nw_proto1}") # Original print
        self.installFlow(event, priority, srcmac1, dstmac1, s_ip1, d_ip1, s_port1, d_port1, nw_proto1) # Original call
        self.allowOther(event) # Original call, this would bypass the rule checking below if executed.

        # >> This is the main loop that correctly applies rules loaded from self.rules
        found_match_and_blocked = False
        for rule in self.rules:
            is_match = True

            if rule['src_mac'] is not None and rule['src_mac'] != match.dl_src:
                is_match = False
            if rule['dst_mac'] is not None and rule['dst_mac'] != match.dl_dst:
                is_match = False

            ip_packet = packet.find('ipv4')
            if ip_packet and is_match:
                if rule['src_ip'] is not None and rule['src_ip'] != ip_packet.srcip:
                    is_match = False
                if rule['dst_ip'] is not None and rule['dst_ip'] != ip_packet.dstip:
                    is_match = False

                if rule['nw_proto'] != 0 and rule['nw_proto'] != ip_packet.protocol:
                    is_match = False

                if is_match and (rule['src_port'] is not None or rule['dst_port'] is not None):
                    if ip_packet.protocol == ipv4.TCP_PROTOCOL:
                        tcp_packet = packet.find('tcp')
                        if not tcp_packet:
                            is_match = False
                        else:
                            if rule['src_port'] is not None and rule['src_port'] != tcp_packet.srcport:
                                is_match = False
                            if rule['dst_port'] is not None and rule['dst_port'] != tcp_packet.dstport:
                                is_match = False
                    else:
                        is_match = False
            elif (rule['src_ip'] or rule['dst_ip'] or rule['nw_proto'] or
                  rule['src_port'] or rule['dst_port']):
                is_match = False

            if is_match:
                log.info(f"  Packet matched L3 Firewall rule (priority {rule['priority']}). Installing blocking flow.") # >> ADDITION HERE: More informative log
                print(f"{rule['priority']}, {rule['src_ip']}, {rule['dst_ip']}, {rule['src_port']}, {rule['dst_port']}, {rule['nw_proto']}")
                self.installFlow(event, rule['priority'], rule['src_mac'], rule['dst_mac'],
                                 rule['src_ip'], rule['dst_ip'],
                                 rule['src_port'], rule['dst_port'],
                                 rule['nw_proto'])
                found_match_and_blocked = True
                break

        if not found_match_and_blocked:
            log.info("  No L3 Firewall rule explicitly blocked the packet. Allowing other traffic.") # >> ADDITION HERE: More informative log
            self.allowOther(event)


def launch(l2config="l2firewall.config", l3config="l3firewall.config"):
    """
    Starts the Firewall module with optional L2 and L3 config files.
    """
    # Original argparse code from your screenshots
    parser = argparse.ArgumentParser(description="L3 Firewall with Port Security")
    parser.add_argument('--l2config', action='store', dest='l2config',
                        help='Layer 2 config file', default='l2firewall.config')
    parser.add_argument('--l3config', action='store', dest='l3config',
                        help='Layer 3 config file', default='l3firewall.config')
    args = parser.parse_args()

    core.registerNew(Firewall, l2config=args.l2config, l3config=args.l3config)
    log.info("L3Firewall (with Port Security) module launched.")